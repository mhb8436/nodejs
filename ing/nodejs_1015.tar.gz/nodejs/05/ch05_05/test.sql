insert into posts(title, content, author, createdAt) values('공지사항7','공지사항7','운영자','2024-09-27'),
('공지사항8','공지사항8','운영자','2024-09-27');
