console.log(String(52));
console.log(typeof(52));
console.log(typeof(String(52)));

console.log(Number("45"));
console.log(Number("H"));
console.log(Number(true));

console.log(isNaN(Number("hello")));

console.log(Boolean(0));
console.log(Boolean(NaN));
console.log(Boolean(1));
console.log(Boolean("H"));
console.log(Boolean(""));

console.log( 25 + 125 );
console.log( "25" + 125 );
console.log( "25" - 125 );