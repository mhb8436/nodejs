let arr = [5, 23, '안녕', true, '홍길동', -9];
let i = 2;
while (i < arr.length) {
    console.log(` ${i} is ${arr[i]}`);
    i++;
}

/*
 2 is 안녕
 3 is true
 4 is 홍길동
 5 is -9
*/