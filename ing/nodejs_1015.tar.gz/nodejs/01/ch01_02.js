console.log(23 + 45);
console.log(23 - 45);
console.log(23 * 45);
console.log(10 / 5);
console.log(10 % 3);

console.log('안녕하세요')
console.log('안녕하세요 "홍길동님" ');
console.log("안녕하세요 \"홍길동님\" ");
console.log("안녕하세요 \n홍길동 입니다.");
console.log("안녕하세요\t홍길동입니다.");
console.log("안녕하세요 \\홍길동입니다.");

console.log("안녕하세요" + "홍길동입니다.");
console.log(`52 + 45 = ${52 + 45}`);

console.log( 52 > 52 );  // false
console.log( 52 == 52 ); // true 
console.log( 52 != 52 ); // false

console.log( 52 >= 52 && 52 > 52); // and 연산자 
console.log( 52 >= 52 || 52 > 52); // or 