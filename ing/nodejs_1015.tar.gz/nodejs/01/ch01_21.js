function add2(x, y) {
    return x + y;
}

console.log(add2(1, 2));

const add1 = function(x, y) {
    return x + y;
}

const add3 = (x, y) => x + y;
console.log(add3(1,3));

// console.log(add1(1,2));