let arr = [5, 23, '안녕', true, '홍길동', -9];
console.log(arr);
console.log(arr[2]);
console.log(arr[5]); // -9 
console.log(arr[arr.length-1]); // -9
