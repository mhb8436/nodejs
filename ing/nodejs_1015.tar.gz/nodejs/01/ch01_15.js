let arr = [5, 23, '안녕',true, '홍길동', -9];
for(let i=0;i<arr.length;i++) {
    console.log(` ${i} is ${arr[i]}`);
}
/* 
 0 is 5
 1 is 23
 2 is 안녕
 3 is true
 */