console.log("Hello World");
console.log('Hello World');
console.log(`Hello ${"world"}`);
