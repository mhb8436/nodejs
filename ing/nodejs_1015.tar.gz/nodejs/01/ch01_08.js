const test = "변경불가";
console.log(`before : ${test}`);
test = "변경해줘";
console.log(`after : ${test}`);