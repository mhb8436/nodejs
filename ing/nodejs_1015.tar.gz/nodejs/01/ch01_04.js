let output = "안녕하세요"
output += "홍길동 입니다."
console.log(output);

let num = 0;
num++;
console.log(`num++: ${num}`); // 1
num--;
console.log(`num--: ${num}`); // 0 
