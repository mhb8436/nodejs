let pi;
console.log(pi);
pi = 3.141592;
console.log(pi);

let pi2 = 3.141592;
console.log(pi2);

let radius = 12;
let area = pi * radius * radius;
let length = pi * 2 * radius;
console.log(`넓이는 : ${area}`);
console.log(`둘레는 : ${length}`);