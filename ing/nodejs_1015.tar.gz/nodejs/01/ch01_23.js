console.log(`parseInt("52") => ${parseInt("52")}`);
console.log(`parseInt("3.14") => ${parseInt("3.14")}`);

console.log(`parseFloat("3.14") => ${parseFloat("3.14")}`);

