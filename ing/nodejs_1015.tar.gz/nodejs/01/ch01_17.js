let arr = [5, 23, '안녕',true, '홍길동', -9];
for(e of arr) {
    console.log(e);
}