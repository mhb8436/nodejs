console.log( typeof(10) );
console.log( typeof("10"));
console.log( typeof(true));

console.log(typeof( function() {} ));
console.log(typeof( {} ))

let beta;
console.log( typeof(beta) );