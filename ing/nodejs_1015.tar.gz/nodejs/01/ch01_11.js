let input = 12;

switch(input % 2) {
    case 0:
        console.log(`짝수입니다.`)
        break;
    case 1:
        console.log(`홀수입니다.`)
        break;
    default:        
        break;
}