// setTimeout(function(){
//     console.log(`1초 뒤에 호출 `);
// }, 1000);


setInterval(function(){
    console.log(`1초 마다 실행`);
}, 1000);