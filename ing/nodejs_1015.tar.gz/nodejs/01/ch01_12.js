let test;
console.log(test);
test = typeof(test) == 'undefined' ? 'initial' : test;
console.log(test);