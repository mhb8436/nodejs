const calc = require('./ch03_01');
console.log(calc.add(2,3));

const subtract = require('./ch03_01');
console.log(calc.subtract(5,1));