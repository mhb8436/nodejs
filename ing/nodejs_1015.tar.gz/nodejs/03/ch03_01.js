const add = (a, b) => a + b;
function subtract(a, b) {
    return a - b;
}
module.exports.subtract = subtract;
module.exports.add = add;


