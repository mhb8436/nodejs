// module 
const add = (a, b) => {
    return a+b; 
}

const subtract = (a,b) => {
    return a - b;
}

module.exports.subtract = subtract;
module.exports.add = add;



