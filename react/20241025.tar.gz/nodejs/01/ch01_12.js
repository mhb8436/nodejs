let arr = [5, 23, 'hello', true, 'world', -9];
console.log(arr);
console.log(arr[2]); // hello
