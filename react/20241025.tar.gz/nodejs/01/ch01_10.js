const input = 12;

switch(input % 2) {
    case 0:
        console.log(`짝수`);
        break;
    case 1:
        console.log(`홀수`);
        break;
    default:
        console.log(`숫자`);
}