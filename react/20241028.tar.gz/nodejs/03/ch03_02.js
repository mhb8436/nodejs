// module 을 사용할 파일 
const calc = require('./ch03_01'); // .js 뺀 파일명
console.log(` 2 + 3 = ${calc.add(2,3)}`);

// 문제 ) 10 - 7 = 3
console.log(`???`)