console.log("Hello World");
console.log("Hello World");
var world = "world";
console.log(`Hello ${world}`);
