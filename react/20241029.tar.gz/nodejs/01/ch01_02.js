console.log(23 + 45);
console.log('this is "string" '); // this is "string"

console.log(`52 + 45 = 5${52 + 4}`); // 템플릿 문자열

console.log("Hello" + " javascript");
console.log("hello \nworld"); // \n 은 줄바꿈
console.log("hello \tworld"); // \t 탭기호
// hello \world
console.log("hello \\world"); // \\ 역슬래시 기호

console.log(52 > 52); //false
console.log(52 >= 52); // true
console.log(45 == 52); // false
console.log(45 != 52); // true

console.log(52 >= 52 && 52 > 52); // true && false => false
console.log(52 >= 52 || 52 > 52); // true || false => true
