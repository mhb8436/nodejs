console.log(typeof 10);
console.log(typeof("hello")) // string
console.log(typeof(true)) //boolean
console.log(typeof(function() {}))
console.log(typeof( {} )); 

let a = 2.3333;
console.log(typeof(a));